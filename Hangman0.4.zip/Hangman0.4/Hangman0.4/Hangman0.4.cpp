﻿#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <conio.h>
using namespace std;

//Function prototypes
void Restart();


//Main functions
void Hangman(int err) {

	if (err == 0)
		cout << "";

	else if (err == 1) {
		cout << "+-----+" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 2) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 3) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 4) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|     |" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 5) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|    /|" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 6) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|    /|\\" << endl;
		cout << "|      " << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 7) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|    /|\\" << endl;
		cout << "|     |" << endl;
		cout << "|      " << endl;
		cout << "|     " << endl;
	}

	else if (err == 8) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|    /|\\" << endl;
		cout << "|     |" << endl;
		cout << "|    / " << endl;
		cout << "|     " << endl;
	}

	else if (err == 9) {
		cout << "+-----+" << endl;
		cout << "|     |" << endl;
		cout << "|     0" << endl;
		cout << "|    /|\\" << endl;
		cout << "|     |" << endl;
		cout << "|    / \\" << endl;
		cout << "|     " << endl;
	}
}

void UpdateScore(int& score, bool correct) {
	if (correct)
		score++;
}

void Procente(int& procente, int score, string& table, string& word) {

	if (score >= 1)
		procente = static_cast<int>((static_cast<double>(score) / word.size()) * 100);

	if (procente > 100)
		procente = 100;

	//collor red
	if (procente <= 33, procente < 34) {
		cout << "Слово угадано на: " << "\033[31m" << procente << "%\033[0m\t\n";
	}
	//collor yellow
	else if (procente >= 34, procente < 67) {
		cout << "Слово угадано на: " << "\033[33m" << procente << "%\033[0m\t\n";
	}
	//collor green
	else if (procente >= 67) {
		cout << "Слово угадано на: " << "\033[32m" << procente << "%\033[0m\t\n";
	}
}

char Input() {
	cout << "\nВведите букву: " << endl;
	char c;
	cin >> c;
	return c;
}

void Table(int n) {
	for (int i = 0; i < n; i++) {
		cout << "+---";
	}
	cout << "+\n";
}

void ShowTable(string table, string word, int procente, int score) {
	Table(table.size());
	cout << "| ";

	for (int i = 0; i < table.size(); i++) {
		cout << table[i] << " | ";
	}

	cout << "\n";
	Table(table.size());
}

void WrongTable(int j) {

	for (int i = 0; i < j; i++) {
		cout << "+---";
	}
	cout << "+\n";
}

void WroningShowTable(const vector<char>& wrongLetters) {
	WrongTable(wrongLetters.size());
	cout << "| ";
	for (char letter : wrongLetters) {
		cout << letter << " | ";
	}
	cout << "\n";
	WrongTable(wrongLetters.size());
}

bool Openletter(string word, string& table, char c) {
	bool found = false;
	for (int i = 0; i < word.size(); i++) {
		if (word[i] == c)
		{
			table[i] = c;
			found = true;
		}
	}
	return found;
}

string RandWord() {
	vector<string> words{
		"свобода",
		"равенство",
		"братство",
		"демократия",
		"республика",
		"конституция",
		"закон",
		"правосудие",
		"мир",
		"кошка",
		"собака",
		"слон",
		"лев",
		"утка",
		"яблоко",
		"банан",
		"апельсин",
		"груша",
		"вишня",
		"стол",
		"стул",
		"ручка",
		"телефон",
		"весна",
		"лето",
		"осень",
		"море",
		"солнце",
		"облако",
		"дождь",
		"снег",
		"ветер",
		"дерево",
		"цветок",
		"птица",
		"животное",
		"дом",
		"семья",
		"друг",
		"любовь",
		"радость",
		"печаль",
		"надежда",
		"мечта",
		"путешествие",
		"приключение",
		"книга",
		"фильм",
		"музыка",
		"танец",
		"спорт",
		"футбол",
		"баскетбол",
		"волейбол",
		"хоккей",
		"бег",
		"плавание",
		"велосипед",
		"гора",
		"долина",
		"река",
		"озеро",
		"лес",
		"поле",
		"город",
		"деревня",
		"улица",
		"квартира",
		"машина",
		"самолет",
		"поезд",
		"корабль",
		"парусная",
		"яхта",
		"катер",
		"мотоцикл",
		"скутер",
		"коньки",
		"лыжи",
		"сноуборд",
		"санки",
		"байдарка",
		"каноэ",
		"каяк",
		"электроскутер",
		"электровелосипед",
		"квадроцикл",
		"мопед",
		"снегоход",
		"внедорожник",
		"грузовик",
		"автобус",
		"троллейбус",
		"трамвай",
		"метро",
		"фуникулер",
		"канатная",
		"лифт",
		"эскалатор",
		"гидросамолет",
		"дирижабль",
		"воздушный",
		"планер",
		"параплан",
		"дельтаплан",
		"вертолет",
		"автожир",
		"роторное",
		"реактивный",
		"космический",
		"ракета",
		"спутник",
		"станция",
		"планета",
		"звезда",
		"галактика",
		"туманность",
		"черная",
		"белая",
		"нейтронная",
		"пульсар",
		"квазар",
		"астероид",
		"комета",
		"метеорит",
		"метеор",
		"болид",
		"сверхновая",
		"гиперновая",
		"гамма-всплеск",
		"вспышка",
		"буря",
		"магнитная",
		"сияние",
		"аврора",
		"молния",
		"гром",
		"гроза",
		"ураган",
		"тайфун",
		"цунами",
		"землетрясение",
		"вулкан",
		"лавина",
		"ополн",
		"наводнение",
		"засуха",
		"пожар",
		"торнадо",
		"смерч",
		"пыльная",
		"песчаная",
		"снежная",
		"ледяная",
		"град",
		"метель",
		"вьюга",
		"шторм",
		"циклон",
		"антициклон",
		"давление",
		"инверсия",
		"градиент",
		"влажность",
		"осадок",
		"облачность",
		"фронт",
		"вихрь",
		"мезоциклон",
		"дьявол",
	};

	int r = rand() % words.size();

	return words[r];
}

int Secondary_Screens() {
	int playAgain = 0;

	do {
		if (playAgain == 0) {
			cout << "Добро пожаловать в игру Виселица! \t\t" << "\033[35m" << "By etft3" << "\033[0m\n\n"
				"Для старта нажмите 1:\n";
			cin >> playAgain;
		}

		if (playAgain == 1) {
			system("cls");
			Restart();
		}

		if (playAgain != 1 || 2) {
			cout << "Для рестарта нажмите 1\t\t Для выхода нажмите 2 " << endl;
			cin >> playAgain;
			system("cls");
		}

		if (playAgain == 2) {
			system("exit");
			return 0;
		}

	} while (playAgain == 1 || playAgain == 2);
}

void Restart() {
	int err = 0;
	int score = 0;
	int procente = 0;

	string word = RandWord();
	string table(word.size(), ' ');

	vector<char> wrongLetters;

	while (table != word && err < 9) {
		Hangman(err);
		cout << "\nСлово\n";
		ShowTable(table, word, procente, score);
		Procente(procente, score, table, word);

		if (err >= 1) {
			cout << "\nОшибки\n";
			WroningShowTable(wrongLetters);
		}

		char c = Input();

		bool correct = Openletter(word, table, c);
		if (!Openletter(word, table, c)) {
			wrongLetters.push_back(c);
			++err;
		}
		else {
			bool found = false;
			for (int i = 0; i < word.size(); i++) {
				if (word[i] == c)
				{
					table[i] = c;
					found = true;
					UpdateScore(score, correct);
				}
			}
		}
		system("cls");
	}

	if (table == word) {
		cout << "\033[32mСлово\n";
		ShowTable(table, word, procente, score);

		if (err != 0) {
			cout << "\033[0m\nОшибки\n";
			WroningShowTable(wrongLetters);
		}
		cout << "\033[32m \nТы победил!\033[0m\n\n" << endl;
	}
	else {
		cout << "\033[31m";
		Hangman(err);
		cout << "\033[0m\nСлово\n";
		ShowTable(table, word, procente, score);
		Procente(procente, score, table, word);
		cout << "\033[31m\nОшибки\n";

		WroningShowTable(wrongLetters);
		cout << "\033[0m\nЭто было слово: " << word << endl << endl;
		cout << "\033[31m" << "Игра окончена!\n" << "\033[0m" << endl;

	}
}

int main() {
	setlocale(LC_ALL, "Ru");
	srand(time(0));
	system("chcp 1251 > null");

	Secondary_Screens();

	return 0;
}